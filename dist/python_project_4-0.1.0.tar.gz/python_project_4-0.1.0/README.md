### Hexlet tests and linter status:
[![Actions Status](https://github.com/RustemYeldessov/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/RustemYeldessov/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/b06bcd90fe5ddcf6b5f9/maintainability)](https://codeclimate.com/github/RustemYeldessov/python-project-49/maintainability)